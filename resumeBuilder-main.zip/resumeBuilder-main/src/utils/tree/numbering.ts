// Numbering system utilities for address-UID mapping
import type { ResumeNode, Numbering } from '../../types';

/**
 * Compute numbering for the entire tree (1-based indexing)
 * Generates bidirectional mappings: address ↔ UID
 */
export function computeNumbering(tree: ResumeNode[]): Numbering {
  const addrToUid: Record<string, string> = {};
  const uidToAddr: Record<string, string> = {};

  function walk(nodes: ResumeNode[], prefix: number[] = []): void {
    nodes.forEach((node, idx) => {
      const addr = [...prefix, idx + 1].join('.');
      node.addr = addr;

      // Only add to mapping if uid exists (it should always exist after ensureUids)
      if (node.uid) {
        addrToUid[addr] = node.uid;
        uidToAddr[node.uid] = addr;
      } else {
        console.warn(`⚠️ Node at ${addr} is missing uid - this should not happen`);
      }

      if (node.children && node.children.length > 0) {
        walk(node.children, [...prefix, idx + 1]);
      }
    });
  }

  walk(tree);
  return { addrToUid, uidToAddr };
}

/**
 * Resolve a numeric address to a UID
 */
export function resolveAddress(
  addr: string, 
  numbering: Numbering
): string | null {
  return numbering.addrToUid[addr] || null;
}

/**
 * Get the numeric address for a given UID
 */
export function getAddress(
  uid: string, 
  numbering: Numbering
): string | null {
  return numbering.uidToAddr[uid] || null;
}

/**
 * Serialize resume tree for AI/LLM consumption with numbered outline
 */
export function serializeForLLM(tree: ResumeNode[]): string {
  const lines: string[] = [];
  
  function write(node: ResumeNode, depth: number): void {
    const addr = node.addr ?? '';
    const pad = '  '.repeat(depth);

    const title = node.title?.trim();
    const textPreview = node.text?.trim()?.split('\n')[0];
    const label = title || textPreview || '(untitled)';

    const printedAddr = depth === 0 ? `${addr}.0` : addr;
    lines.push(`${pad}${printedAddr} ${label}`);

    node.children?.forEach((c) => write(c, depth + 1));
  }
  
  tree.forEach((n) => write(n, 0));
  return lines.join('\n');
}